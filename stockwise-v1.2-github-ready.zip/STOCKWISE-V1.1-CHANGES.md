# Stockwise V1.1 changes

- Fixed Buying Bar direction: stronger ROI now moves toward Sweet Spot rather than Walk Away.
- Connected Buying Rules to the live decision engine.
- Added fourth rule: maximum units on a first purchase.
- Settings now update the decision engine immediately.
- Added a dedicated barcode/EAN field instead of reusing product name.
- Added Stock Memory recognition when the same barcode is analysed again.
- Saved opportunities now retain barcode/EAN data.
- Decision explanation now shows pass/fail against the user's current rules.
- Added raw-economics mode when Buying Rules are disabled.

## Recommended V1.2

1. Persist opportunities and settings with localStorage, then Postgres/Supabase.
2. Replace demo Stock Memory cards with true grouping by EAN and dated observations.
3. Make wholesale catalogue upload parse real CSV/XLSX files.
4. Recalculate wholesale rows from imported costs and the same Buying Rules engine.
5. Turn Shortlist into a real Order Builder with quantities, delivery allocation and order-health recalculation.
6. Add Actual Outcome: purchased quantity, actual sell price, units sold, remaining stock and realised profit.
7. Add confidence inputs for selling-price source and previous purchase history.
8. Add catalogue delta: new SKUs, price drops, price rises and products that newly meet rules.
