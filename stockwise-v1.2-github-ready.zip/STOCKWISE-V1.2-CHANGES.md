# Stockwise V1.2 — Purchasing Intelligence

V1.2 extends the fixed V1.1 buying engine into a purchase-outcome loop.

## Added
- Opportunity lifecycle statuses
- Mark-as-purchased workflow
- Completed outcome tracking with expected-vs-actual profit and ROI
- Monthly buying budget and capital-impact display
- Minimum margin and first-purchase-capital buying rules
- Selling-price source and UNVERIFIED manual-estimate indicator
- TEST BUY logic now considers confidence/history as well as economics
- Portfolio capital, realised profit and purchase-history views
- GitHub-ready README and proprietary-code notice

## Retained
- V1.1 Buying Bar direction fix
- Settings-driven decision engine
- EAN/barcode capture and repeat recognition
- Wholesale Opportunities workflow
- Stock Memory, Suppliers and existing visual system

## Next
- Replace prototype/local state with persistent database storage
- Make wholesale CSV/XLSX import process real file data
- Group Stock Memory by canonical EAN rather than display cards
- Add editable purchase/outcome modal fields
- Add catalogue delta between supplier uploads
